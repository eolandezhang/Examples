﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.ServiceProcess;

namespace QPP.Project.WindowsServiceUI
{
    //System.ServiceProcess.ServiceControllerStatus
    //ContinuePending	服务即将继续。 这对应于 Win32 SERVICE_CONTINUE_PENDING 常数，该常数定义为 0x00000005。
    //Paused	服务已暂停。 这对应于 Win32 SERVICE_PAUSED 常数，该常数定义为 0x00000007。
    //PausePending	服务即将暂停。 这对应于 Win32 SERVICE_PAUSE_PENDING 常数，该常数定义为 0x00000006。
    //Running	服务正在运行。 这对应于 Win32 SERVICE_RUNNING 常数，该常数定义为 0x00000004。
    //StartPending	服务正在启动。 这对应于 Win32 SERVICE_START_PENDING 常数，该常数定义为 0x00000002。
    //Stopped	服务未运行。 这对应于 Win32 SERVICE_STOPPED 常数，该常数定义为 0x00000001。
    //StopPending	服务正在停止。 这对应于 Win32 SERVICE_STOP_PENDING 常数，该常数定义为 0x00000003。
    public enum CustomServiceControllerStatus
    { 
        ContinuePending,    //服务即将继续
        Paused,             //服务已暂停
        PausePending,       //服务即将暂停
        Running,            //服务正在运行
        StartPending,       //服务正在启动
        Stopped,            //服务未运行
        StopPending,        //服务正在停止
        NotFound            //找不到服务
    }



  //   Dictionary<int, string> dic = new Dictionary<int, string>{
  //    {1,"A"}, {2,"B"}, {3,"C"}, {4,"D"},{5,"E"},
  //    {6,"F"}, {7,"G"}, {8,"H"},{9,"I"},{10,"J"},
  //    {11,"K"},{12,"L"},{13,"M"},{14,"N"},{15,"O"},
  //    {16,"P"},{17,"Q"},{18,"R"},{19,"S"},{20,"T"},
  //    {21,"U"}, {22,"V"},{23,"W"}, {24,"X"},{25,"Y"},
  //    {26,"Z"}
  //};
	/// <summary>
	/// MainWindow.xaml 的交互逻辑
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

        private string serviceName = "QPP.Project.Sync";

        private Dictionary<ServiceControllerStatus, CustomServiceControllerStatus> dicStatus = new Dictionary<ServiceControllerStatus, CustomServiceControllerStatus>() { 
            { ServiceControllerStatus.ContinuePending,CustomServiceControllerStatus.ContinuePending},
            { ServiceControllerStatus.Paused,         CustomServiceControllerStatus.Paused},       
            { ServiceControllerStatus.PausePending,   CustomServiceControllerStatus.PausePending},
            { ServiceControllerStatus.Running,        CustomServiceControllerStatus.Running},
            { ServiceControllerStatus.StartPending,   CustomServiceControllerStatus.StartPending},
            { ServiceControllerStatus.Stopped,        CustomServiceControllerStatus.Stopped},    
            { ServiceControllerStatus.StopPending,    CustomServiceControllerStatus.StopPending}
        };
        private Dictionary<CustomServiceControllerStatus, string> dicStatusString = new Dictionary<CustomServiceControllerStatus, string> { 
            { CustomServiceControllerStatus.ContinuePending,"即将继续"},
            { CustomServiceControllerStatus.Paused,         "已暂停"},
            { CustomServiceControllerStatus.PausePending,   "即将暂停"},
            { CustomServiceControllerStatus.Running,        "正在运行中"},
            { CustomServiceControllerStatus.StartPending,   "正在启动"},
            { CustomServiceControllerStatus.Stopped,        "未运行"},
            { CustomServiceControllerStatus.StopPending,    "正在停止"},
            { CustomServiceControllerStatus.NotFound,       "找不到"}
        };

		private void btnInstall_Click(object sender, RoutedEventArgs e)
		{
            var status = GetServiceControllerStatus();
            if (status == CustomServiceControllerStatus.NotFound)
            {
                DoInstall();
            }
            else
            {
                lblCheckStatus.Text = String.Format("已安装过Windows服务\"{0}\"。\n服务\"{1}\"的状态：{2}", serviceName, serviceName, dicStatusString[status]);
            }
		}


        private void DoInstall()
        {
            string CurrentDirectory = System.Environment.CurrentDirectory;
            System.Environment.CurrentDirectory = CurrentDirectory + "\\Service";
            Process process = new Process();
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.FileName = "Install.bat";
            process.StartInfo.CreateNoWindow = true;
            process.Start();
            lblCheckStatus.Text = String.Format("Windows服务\"{0}\" 安装成功！", serviceName); 
            System.Environment.CurrentDirectory = CurrentDirectory;
        }


		private void btnUninstall_Click(object sender, RoutedEventArgs e)
		{
            var status = GetServiceControllerStatus();
            if (status == CustomServiceControllerStatus.NotFound)
                lblCheckStatus.Text = String.Format("找不到Windows服务\"{0}\"。\n无需卸载。", serviceName);
            else
                DoUnInstall();
		}


        private void DoUnInstall()
        {
            string CurrentDirectory = System.Environment.CurrentDirectory;
            System.Environment.CurrentDirectory = CurrentDirectory + "\\Service";
            Process process = new Process();
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.FileName = "Uninstall.bat";
            process.StartInfo.CreateNoWindow = true;
            process.Start();
            lblCheckStatus.Text = String.Format("Windows服务\"{0}\" 卸载成功！", serviceName);
            System.Environment.CurrentDirectory = CurrentDirectory;
        }


        private CustomServiceControllerStatus GetServiceControllerStatus()
        {
            ServiceController serviceController = new ServiceController(serviceName);
            try
            {
                //if (serviceController.Status )
                return dicStatus[serviceController.Status];
            }

            catch (InvalidOperationException ex)
            {
                // lblCheckStatus.Text = "未找到服务";
                return CustomServiceControllerStatus.NotFound;

            }
            //  
            catch (Exception ex)
            {
                return CustomServiceControllerStatus.NotFound;

                //lblCheckStatus.Text = ex.Message;
            }

        }


		private void btnCheckStatus_Click(object sender, RoutedEventArgs e)
		{
            var status = GetServiceControllerStatus();
            lblCheckStatus.Text = String.Format("Windows服务\"{0}\"{1}", serviceName, dicStatusString[status]); 
            //ServiceController serviceController = new ServiceController(serviceName);
            //try
            //{
            //    lblCheckStatus.Text = serviceController.Status.ToString();
            //}

            //catch (InvalidOperationException ex)
            //{

            //    lblCheckStatus.Text = "未找到服务";
                
            //}
            //  //  
            //catch (Exception ex)
            //{

            //    lblCheckStatus.Text = ex.Message;
            //}
			
		}

		private void btnStart_Click(object sender, RoutedEventArgs e)
		{
            var status = GetServiceControllerStatus();
            if (status == CustomServiceControllerStatus.NotFound)
            {
                lblCheckStatus.Text = String.Format("找不到Windows服务\"{0}\"。\n无法启动该服务。\n请先安装该服务。", serviceName);
            }

            else if (status == CustomServiceControllerStatus.Running )
            {
                lblCheckStatus.Text = String.Format("Windows服务\"{0}\"{1}", serviceName, dicStatusString[status]); 
            }
            else
                DoStart(); 
            //ServiceController serviceController = new ServiceController(serviceName);
            //try
            //{
            //    lblStatus.Text = "服务已启动";
            //}
            //catch (Exception ex)
            //{
            //    lblStatus.Text = ex.Message;
            //}
            //serviceController.Start();
			
		}

        private void DoStart()
        {
            ServiceController serviceController = new ServiceController(serviceName);
            try
            {
                if (serviceController.Status != ServiceControllerStatus.Running && serviceController.Status != ServiceControllerStatus.StartPending)
                    serviceController.Start();
                lblCheckStatus.Text = String.Format("Windows服务\"{0}\"已启动。", serviceName);
            }
            catch (Exception ex)
            {
                lblCheckStatus.Text = ex.Message;
            }
        }

		private void btnStop_Click(object sender, RoutedEventArgs e)
		{
            var status = GetServiceControllerStatus();
            if (status == CustomServiceControllerStatus.NotFound)
            {
                lblCheckStatus.Text = String.Format("找不到Windows服务\"{0}\"。\n无法停止该服务。\n请先安装该服务。", serviceName);
            }
            else if (status == CustomServiceControllerStatus.Stopped )
            {
                lblCheckStatus.Text = String.Format("Windows服务\"{0}\"{1}", serviceName, dicStatusString[status]); 
            }
            else
            {
                DoStop();
            }
            //ServiceController serviceController = new ServiceController(serviceName);
            //if (serviceController.CanStop)
            //{
            //    try
            //    {
            //        serviceController.Stop();
            //        lblStatus.Text = "服务已停止";
            //    }
            //    catch (Exception ex)
            //    {
            //        lblStatus.Text = ex.Message;
            //    }
				
            //}
            //else
            //    lblStatus.Text = "服务不能停止";
		}

        private void DoStop()
        {
            ServiceController serviceController = new ServiceController(serviceName);
            if (serviceController.CanStop)
            {
                try
                {
                    if (serviceController.Status != ServiceControllerStatus.Stopped && serviceController.Status != ServiceControllerStatus.StopPending)
                        serviceController.Stop();
                    lblCheckStatus.Text = String.Format("Windows服务\"{0}\"已停止。", serviceName);
                }
                catch (Exception ex)
                {
                    lblCheckStatus.Text = ex.Message;
                }

            }
            else
                lblCheckStatus.Text = "服务不能停止";
        }
        //private ServiceControllerStatus


        //private void btnPauseContinue_Click(object sender, RoutedEventArgs e)
        //{
        //    var status = GetServiceControllerStatus();
        //    if (status == CustomServiceControllerStatus.NotFound)
        //    {
        //        lblCheckStatus.Text = String.Format("找不到Windows服务\"{0}\"。\n请先安装该服务。", serviceName);
        //    }
        //    else
        //    {
        //        DoPauseContinue();
        //    }
        //}

        //private void DoPauseContinue()
        //{
        //    ServiceController serviceController = new ServiceController(serviceName);
        //    if (serviceController.CanPauseAndContinue)
        //    {
        //        if (serviceController.Status == ServiceControllerStatus.Running)
        //        {
        //            try
        //            {
        //                serviceController.Pause();
        //                lblCheckStatus.Text = "服务已暂停";

        //            }
        //            catch (Exception ex)
        //            {

        //                lblStatus.Text = ex.Message;
        //            }
        //        }
        //        else if (serviceController.Status == ServiceControllerStatus.Paused)
        //        {
        //            try
        //            {
        //                serviceController.Continue();
        //                lblCheckStatus.Text = "服务已继续";

        //            }
        //            catch (Exception ex)
        //            {

        //                lblCheckStatus.Text = ex.Message;
        //            }

        //        }
        //        else
        //        {
        //            lblCheckStatus.Text = "服务未处于暂停和启动状态";
        //        }
        //    }
        //    else
        //        lblCheckStatus.Text = "服务不能暂停";
        //}
	}
}
