WindowsServiceTest
==================

This is Demo for Article .
http://www.cnblogs.com/sorex/archive/2012/05/16/2502001.html